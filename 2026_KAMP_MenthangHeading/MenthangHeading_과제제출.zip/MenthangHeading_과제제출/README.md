# Transformer·Mamba·LSTM Autoencoder + Adaptive Threshold

## 프로젝트 개요
본 프로젝트는 프레스 유압펌프의 진동 및 전류 시계열 데이터를 이용하여 설비의 이상 상태를 탐지하는 모델입니다.

가이드북의 LSTM Autoencoder를 Baseline으로 사용하고, Transformer Autoencoder와 Mamba Autoencoder를 추가로 구성하여 동일한 데이터 전처리 및 평가조건에서 성능을 비교하였습니다.

세 모델 모두 정상 시계열 데이터를 학습한 후 입력 데이터를 재구성하며, 이 과정에서 생성되는 `Latent Vector`와 `Reconstruction Error`를 Adaptive Threshold Model의 입력으로 사용합니다. Adaptive Threshold Model은 Latent Vector를 기반으로 각 Window에 적합한 Threshold를 생성하고, Reconstruction Error와 Threshold의 차이를 이용하여 이상 여부를 판단합니다.

최종 모델은 **Mamba Autoencoder + Adaptive Threshold Model**입니다.

## 사용 모델
- LSTM Autoencoder
- Transformer Autoencoder
- Mamba Autoencoder
- Adaptive Threshold Model

## 데이터
사용 데이터:
- `press_data_normal.csv`
- `outlier_data.csv`

주요 입력 변수:
- `AI0_Vibration`
- `AI1_Vibration`
- `AI2_Current`
- `Equipment_state`
  - `0`: Normal
  - `1`: Anomaly

## 모델 동작 흐름
```text
센서 데이터
→ Min-Max Scaling
→ Sequence Window 구성
→ LSTM / Transformer / Mamba Autoencoder
→ Latent Vector + Reconstruction Error 생성
→ Adaptive Threshold Model 입력
→ Window별 Adaptive Threshold 생성
→ Reconstruction Error와 Threshold 비교
→ Normal / Anomaly 판단
```

Autoencoder는 정상 데이터의 시계열 패턴을 학습하며, Adaptive Threshold Model은 Validation 데이터의 `Latent Vector`, `Reconstruction Error`, `Equipment_state`를 이용하여 학습합니다.

## 실행 환경
- Python 3.11.16
- TensorFlow 2.21.0
- NumPy 2.4.6
- Pandas 3.0.6
- scikit-learn 1.9.1
- Matplotlib 3.11.2
- Seaborn 0.13.2

패키지 설치:

```bash
pip install -r requirements.txt
```

## 실행
```bash
python src/adaptive_threshold_lstm_ae.py
python src/adaptive_threshold_transformer_ae.py
python src/adaptive_threshold_mamba_ae.py

python src/only_threshold_for_lstm_ae.py
python src/only_threshold_for_transformer_ae.py
python src/only_threshold_for_mamba_ae.py
```

실제 경로가 다를 경우 해당 경로에 맞게 수정하여 실행합니다.

## 테스트 결과
테스트 결과 CSV 파일에는 다음 항목을 저장합니다.

```text
sequence_index
actual_label
reconstruction_error
adaptive_threshold
anomaly_probability
predicted_label
```

예시:

```text
results/test_predictions.csv
```

## 제출 폴더 구조
```text
project_submit/
├─ data/
│  ├─ press_data_normal.csv
│  └─ outlier_data.csv
│
├─ src/
│  ├─ adaptive_threshold_lstm_ae.py
│  ├─ adaptive_threshold_mamba_ae.py
│  ├─ adaptive_threshold_transformer_ae.py
│  ├─ only_threshold_for_lstm_ae.py
│  ├─ only_threshold_for_mamba_ae.py
│  └─ only_threshold_for_transformer_ae.py
│
├─ predicted_testdata_results/
│  ├─ lstm/
│  │  ├─ best_seq_20/
│  │  ├─ seq_20/
│  │  └─ seq_50/
│  │
│  ├─ mamba/
│  │  ├─ seq_20/
│  │  └─ seq_50/
│  │
│  └─ tf/
│     ├─ seq_20/
│     └─ seq_50/
│
├─ requirements.txt
└─ README.md
```
각 결과 폴더에는 해당 실험의 예측 CSV, 그래프, Evaluation 결과 및 Autoencoder Weight가 저장되어 있습니다.